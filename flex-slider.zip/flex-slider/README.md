# Flex Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/byeeemoni/pen/gOKyQxZ](https://codepen.io/byeeemoni/pen/gOKyQxZ).

